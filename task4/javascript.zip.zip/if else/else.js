//we use if& else statement
//   let num=+prompt("print any number")
//     if(num%2==0){
//     console.log("found a even number");
//    } else {
//     console.log("found a odd number");
//    }
//  //find the largest of two number
// function y(num1,num2){
//  if(num1<num2){
//    console.log("num1 is greter than num2");
//  } else {
//    console.log("num1 is less than num2");
//  }}
//  y(70,50);

// //perform arthmatic operation two number
//   let s=10;
//       b=20;{
//       console.log("addition is"+(s+b));
//       console.log("subsraction is"+(s-b));
//       console.log("multiplication is"+(s*b));
//      console.log("division is"+(s/b));
//       }
// //neasted if 

//   let(age= 20);
//    if(age >= 18);
//     if(age>=15){
//     console.log("yore voted!");
//      } else  {
//     console.log("age is out off limit");
//      console.log("youre chailed");
//    }
//  //nested if else
//   let age=20;
//   if (age = 18)
//   if(age===200){
//   console.log("your valied!");
//   } else {
//    if(age>=100)
//    console.log("your minar check few year");
//    console.log("you are cross the limit age");
//  } else {
//     console.log("your child");
//  }
// //using the for loop
//  let A=20;
//   for(A=1;A>=20; A++){
//     console.log(A*2);
//   }

//   }
// // console.log("##print for loop print 1 to 10 by using for loop##");
//  let i=20;
//   for (i=0; i<=10; ){
//   console.log(i+2);
//   i++;
//  }
// // console.log("##print even number by using for loop##");
//  let j=20;
//   for (j=0; j<=10; ){
//  console.log(j*2);
//   j++;
//  }
// // console.log("##print odd number by using for loop##");
//  for (let j=1; j<=20; j++){
//    if(j%2 !== 0){
//   console.log(j);
//  }
//  }
//  //swich statement
//   let choose=prompt(`choose the nmuber 
//   1)22
//  2)11
//  `);
//    switch (choice){
//    case 1:
//  console.log(22);
//    case 2:
//    console.log(22);
//  }
// }
// //accept two number from user
//  let a=+prompt("enter the frist number");
//  let b=+prompt("enter the second number");
//  let operator=prompt(`(oprator)=>
//  + addition
//  - substraction
//  * multiplication
//  / division
//  % mod
//  ** power`);

//         switch (operator){
//                   case '+':
//  console.log("addition of two number "+(a+b));
//          break;
//          case '-':
//         console.log("substraction of two nmuber "+(a-b)); 
//          break;
//          case '*':
//       console.log("multiplication of two nmuber "+(a*b));
//              break;
//               case '/':
//                console.log("division of two nmuber "+(a/b));
//                break;
//                case '%':
//                 console.log("multiplication of two nmuber "+(a%b));
//                        break;
//                        case '*':
//                         console.log("multiplication of two nmuber "+(a**b));
//                                break;
//         }
