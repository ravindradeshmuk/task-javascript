//alert("hallo");
 //prompt("enter your nmuber");
// function add(number1,number2);
//   {
//  console.log(`addition is :${number1 + number2}`);
//  }
//  let number1= 10;
//  let number2= 12;
//  add(number1,number2);
// }
// add(number1,number2);
//let a = true;
//console.log(Number  (a))
//     console.log(num1+num2);
// }
// add(10,22);

// function mult();{
// let num1=("num1*num2");
//     console.log(num1);
// }
// mult(11,3);
//add the new element at the end
let number=[11,12,13,14,15];
number.push[16];
console.log(number);


