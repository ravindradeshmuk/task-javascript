// function add() {
// console.log(10+5);
// }
// add();
// //simple two to veriable addtion by using prompt
// prompt("enter your number!");
// let number1= 10;
// let number2= 20;
// function add(number1,number2){
//  console.log("Addition is:"+(number1+number2));
// }
// add(number1,number2);

let a =true;
console.log(typeof (a));

// let name= "10";
// console.log(Number(name));

// function add(name){
//    console.log(`hello ${name} welcome to maxotag`);
// }
// add("virat");
// add("ravi");
// add("dhoni")
// function add  (num1,num2,numb3,numN){
//    console.log("addition is:" +num1+ num2);
//     return();

// }
//   function(add);

//    function sum(num1 = 4, num2 = 4, num3 = 4) {
//        //return num1 + num2 + num3;
//      if (typeof num1 != "number") {
//       // return "Please Enter a Valid Number";
//      }
  
//      console.log("Addition Of 3 Numbers Is : " + (num1 + num2 + num3));
//    }
// //     //fucntion call for sum function
//     let Result = sum(10, 20);
//     console.log(Result);
//     console.log("result = " + Result);
//      function sum( num1 = 2, num2 = 2, num3 = 2){
//  if (typeof num1 != "number"){
//       return "please enter valid number";
//  }  
//  console.log("addition of 3 number is:" + (num1 + num2 + num3));
//    }
//     const R = sum(10, 20);
//  console.log (result);
//  function sum(num1 = 3, num2 = 3, num3 = 3) {
//       //return num1 +
//  num2 + num3;
//    if (typeof num1 != "number") {
//      return "Please Enter a Valid Number";
//    }

//   console.log("Addition Of 3 Numbers Is : " + (num1 + num2 + num3));
//  }

// fucntion call for sum function
//  let result = sum(10, 20);
// console.log(result);
// console.log("result =" + result);
//  console .log("##arrow functioncall##");
//  let name=(num1,num2)=>{
//       console.log(num1+num2);
//   };
//   name(12,20);

//  let add=(num1,num2)=>{
//    console.log(num1+num2);
// };
//  add(23,45);

//  let b=(num1,num2)=>{
//      console.log(num1+num2);
//  };
//  b(1,1);

//  let d=(num1,num2)=>{
//      console.log(num1+num2);
//  };
//  d(123,567);

//  let s=(num1,num2)=>{
//     console.log(num1+num2);
//  };
//  s(12,89);
//  console.log("##without parameter##");
//  let printText=()=>{
//     console.log("hallo maxotag how are maxotag")};
//   printText();
//   let p=()=>{
//     console.log("i am larning MERNSTACK course")};
//    p();
//  let t=()=>{
//    console.log("acttualy daily i was solve the problem in my life but now dialy solve the error")};
//   t();
//  let v=()=>{
//   console.log("NOW this is swichwesion my life")};
//    v();
       
//    console.log ("##without curly braces##")
//   let ab = () => 5*3;
//    console.log(ab());
//    let zx = () => 12*3;
//    console.log(zx());
//    let cv = () => 23*5;
//    console.log(cv());
//    let sd = () => 33*8;
//    console.log(sd());
//    let bn = () => 10*10;
//    console.log(bn());
//  console.log("##without parenthesis##")
//  let numberSquear = n1 => n1*n1;{
//  console.log(numberSquear(11));
//  }
 
//  let er= n2 => n2*n2;
//  console.log(er(12));
//  let ty= n3 => n3*n3;
//  console.log(ty(5));
//  let ui= n4 => n4*n4;
//  console.log(ui(8));
//  let op= n5 => n5*n5;
//  console.log(op(9));

//  console.log("##function expression##");
//  let num=(n1,n2) => {
//     console.log(n1*n2);
//  }
//  num(2,3);
// let rollno=5;
// console.log(rollno);
// we use if& else statement
//   let num=+prompt("print any number")
//     if(num%2==0){
//     console.log("found a even number");
//    } else {
//     console.log("found a odd number");
//    }
//  //find the largest of two number
// function y(num1,num2){
//  if(num1<num2){
//    console.log("num1 is greter than num2");
//  } else {
//    console.log("num1 is less than num2");
//  }}
//  y(70,50);

// //perform arthmatic operation two number
//   let s=10;
//       b=20;{
//       console.log("addition is"+(s+b));
//       console.log("subsraction is"+(s-b));
//       console.log("multiplication is"+(s*b));
//      console.log("division is"+(s/b));
//       }
// //neasted if 

//   let(age= 20);
//    if(age >= 18);
//     if(age>=15){
//     console.log("yore voted!");
//      } else  {
//     console.log("age is out off limit");
//      console.log("youre chailed");
//    }
//  //nested if else
//   let age=20;
//   if (age = 18)
//   if(age===200){
//   console.log("your valied!");
//   } else {
//    if(age>=100)
//    console.log("your minar check few year");
//    console.log("you are cross the limit age");
//  } else {
//     console.log("your child");
//  }
// //using the for loop
//  let A=20;
//   for(A=1;A>=20; A++){
//     console.log(A*2);
//   }

//   }
// // console.log("##print for loop print 1 to 10 by using for loop##");
//  let i=20;
//   for (i=0; i<=10; ){
//   console.log(i+2);
//   i++;
//  }
// // console.log("##print even number by using for loop##");
//  let j=20;
//   for (j=0; j<=10; ){
//  console.log(j*2);
//   j++;
//  }
// // console.log("##print odd number by using for loop##");
//  for (let j=1; j<=20; j++){
//    if(j%2 !== 0){
//   console.log(j);
//  }
//  }
//  //swich statement
//   let choose=prompt(`choose the nmuber 
//   1)22
//  2)11
//  `);
//    switch (choice){
//    case 1:
//  console.log(22);
//    case 2:
//    console.log(22);
//  }
// }
// //accept two number from user
//  let a=+prompt("enter the frist number");
//  let b=+prompt("enter the second number");
//  let operator=prompt(`(oprator)=>
//  + addition
//  - substraction
//  * multiplication
//  / division
//  % mod
//  ** power`);

//         switch (operator){
//                   case '+':
//  console.log("addition of two number "+(a+b));
//          break;
//          case '-':
//         console.log("substraction of two nmuber "+(a-b)); 
//          break;
//          case '*':
//       console.log("multiplication of two nmuber "+(a*b));
//              break;
//               case '/':
//                console.log("division of two nmuber "+(a/b));
//                break;
//                case '%':
//                 console.log("multiplication of two nmuber "+(a%b));
//                        break;
//                        case '*':
//                         console.log("multiplication of two nmuber "+(a**b));
//                                break;
//         }
