// let name="ravi";
// ///alert("hallo" + name);
// var firstName = "kiran";
// var lastname = "more";
// console.log(firstName );
// console.log(lastname);




// //let=>
// {

// }
// let firstName = "ravi";
// console.log(firstName);

// //cons=>
// {
    // const a = 19;
    // const d = 34;
    
    // console.log(a+d);
    // console.log(d);
//     }
//  var firstName = "kiran";
//  let lastName = "more";
//   const fullName = "deshmukh";
// console.log(fullName);
//  let admin;
//   let name1 = "jonh";
//   admin = name1;
//   alert(admin);
 //--------------------------------------------

// {
// let myname="ravi";
// console.log(myname);
// }
//  var a = 30;
//      b = 10;
//      console.log( a+b);
//      console.log (a-b);
//       console.log( a*b);
//        console.log( a%b); 
//        console.log( a+=b);

//       var d = 5;
  //           c=10;
   //console.log(d<c);
   let a;
   console.log(typeof (a));

// let fdfdvhf = 134;
// console.log(fdfdvhf);

// alert("z=x+y");

// let y=7.5;
// let x=7.5;
// console.log(y+x);

// var r = 30;
//     m = 10;
//    console.log( r+m);
//      console.log (r-m);
//       console.log( r*m);
//        console.log( r%m); 
//     //logical opration=>&&
//     console.log("logical opration AND")
//     let a=true;
//     let b=true;
//     console.log(a&&b);

//     let c=true;
//     let d=false;
//     console.log(c&&d);

//     let e=false;
//     let f=true;
//     console.log(e&&f);

//     let i=false;
//     let j=false;
//     console.log(i&&j);
//     //opration=>||
//     console.log("logical opration OR")
//     let k=true;
//     let l=true;
//     console.log(k||l);

//     let m=true;
//     let n=false;
//     console.log(m||n);

//     let o=false;
//     let p=true;
//     console.log(o||p);

//     let q=false;
//     let r=false;
//     console.log(q||r);
//     //CONCATENATION OPRATOR VS STRING LITERAL'S
//     console.log("# concatenation oprator vs string litterals")
//     let firstName="ravi";
//     let course="MERN STACK";
//     console .log("my name is " + firstName + " i am larning " + course);
//     console .log(`my name is  ${firstName}   i am larning ${course}`);
// //function=>
// {
//   function z(num1,num2);
// return num1;
//        num2;
//   console.log(num1+num2);
// }
//  fun();




    