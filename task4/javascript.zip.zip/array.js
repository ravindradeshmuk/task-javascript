//array =>add the element at the end
// let number=[1,2,2,3,4,5,6];
// number.push(5);
// console.log(number);
// //remove element last elemnt
// let number1=[1,2,2,3,4,5,6];
// number1.pop();
// console.log(number1);
// //add new element at start:
// let number2=[1,23,4,54,32,44,55]
// number2.unshift(5);
// console.log(number2);
// //delete new element from start
// let number3=[1,2,2,3,4,5,6];
// number3.shift();
// console.log(number3);
// //delete first number and add the name
//  let name ="ravi";
//  let number4 =["name",2,2,3,4,5,6];
//  console.log(name);
 //array method function
//  const names=["name",true,52,undefined,null];
//  console.log(names);
//  console.log(names[2],names[1]);
 // //1)map,filter,foreach reduce
// let numbers=[10,20,30,40,50,50];
//  console.log(numbers);
//   numbers.map((a,index)=>{
//    console.log(a,index);
//   });
//   numbers.map((a,index, array)=>{
//   console.log(array);
//   });

    
     
    //filter
    //  let mobile = [
    //      {   brand:"Mi",
    //          model:"7 pro",
    //          price:10000,
    //      }
    //       {   
    //           brand:"oppo",
    //         model:"reh 5 pro",
    //         price:10000,
    //       }    
    //      {
    //         brand:"redme",
    //           model:"6 pro",
    //          price:10000,

    //     {
          
    //       brand:"Mi",
    //       model:"6 pro",
    //      price:10000,
    //     }
    //       }];
        
    // console.log(Mimobile);
    // let result=mobile.brand;{
    //   if (mobile.brand==="Mi")=>{
    // return true;
    //     }  }
    //     console.log(result);
    //     console,log(Mimobile);
    // //reduce
    // let number=[1,2,12,11];{
    //    let add=total+number;
    //    return totale;
    // };
    //  console.log(add);

  